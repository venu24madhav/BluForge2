"""Exact ACL throughput from the kernel's HCI monitor channel.

Every ACL packet the host hands to a controller (and every one it receives) is
mirrored on HCI_CHANNEL_MONITOR, together with the controller's own
"Number Of Completed Packets" events. Counting those gives byte-exact rates, with
no polling of deprecated tools and no sampling error:

  tx   ACL bytes the host handed to the controller (L2CAP header + payload)
  done ACL bytes the controller reports as completed (sent and acknowledged, or
       flushed); matched to sent packets in FIFO order per connection handle
  rx   ACL bytes received from the remote

Rates are taken between two snapshots over their exact elapsed time. Over-the-air
retransmissions and baseband overhead are not visible to the host, so this is
ACL-level throughput, not raw radio bit rate.
"""
import socket
import struct
import threading
import time
from collections import deque

from hci_raw import _hci_bind, AF_BLUETOOTH, BTPROTO_HCI

HCI_CHANNEL_MONITOR = 2
HCI_DEV_NONE = 0xFFFF
MON_EVENT_PKT, MON_ACL_TX, MON_ACL_RX, MON_SCO_TX, MON_SCO_RX = 3, 4, 5, 6, 7
EVT_DISCONN_COMPLETE, EVT_CONN_COMPLETE, EVT_NUM_COMPLETED, EVT_LE_META = 0x05, 0x03, 0x13, 0x3E
FIFO_MAX = 4096
RCVBUF_BYTES = 8 * 1024 * 1024        # room for a burst: the kernel does not report dropped monitor frames
SO_RCVBUFFORCE = 33
STARTUP_GRACE_PKTS = 64               # completions for packets sent just before we started are normal
MAX_BACKLOG_PKTS = 128                # a controller buffers far fewer; more means completion events were missed


class AclMeter(threading.Thread):
    def __init__(self, hci_index):
        super().__init__(daemon=True, name="acl-meter")
        self.hci = hci_index
        self.sock = None
        self.lock = threading.Lock()
        self.stop_ev = threading.Event()
        self.c = {}                 # handle -> counters
        self.addr_of = {}           # handle -> BD_ADDR (from connection-complete events seen)
        self.fifo = {}              # handle -> deque of ACL data lengths awaiting completion
        self.error = None
        self.frames = 0
        self.truncated = 0          # frames the kernel cut short (would make byte counts wrong)

    # ------------------------------------------------------------- lifecycle
    def open(self):
        s = socket.socket(AF_BLUETOOTH, socket.SOCK_RAW | socket.SOCK_CLOEXEC, BTPROTO_HCI)
        try:
            _hci_bind(s, HCI_DEV_NONE, HCI_CHANNEL_MONITOR)
        except OSError:
            s.close()
            raise
        s.settimeout(0.5)
        for opt in (SO_RCVBUFFORCE, socket.SO_RCVBUF):       # root may exceed rmem_max; fall back if refused
            try:
                s.setsockopt(socket.SOL_SOCKET, opt, RCVBUF_BYTES)
                break
            except OSError:
                continue
        self.sock = s
        return self

    def close(self):
        self.stop_ev.set()
        if self.is_alive():
            self.join(2)
        if self.sock:
            try:
                self.sock.close()
            except OSError:
                pass
            self.sock = None

    # ------------------------------------------------------------- parsing
    def _ctr(self, h):
        return self.c.setdefault(h, {"tx_b": 0, "tx_p": 0, "done_b": 0, "done_p": 0, "done_unmatched": 0,
                                     "rx_b": 0, "rx_p": 0, "sco_tx_b": 0, "sco_rx_b": 0})

    def feed(self, opcode, payload):
        """Account one monitor frame's payload (separate from I/O so it can be unit-tested)."""
        with self.lock:
            if opcode in (MON_ACL_TX, MON_ACL_RX) and len(payload) >= 4:
                h = struct.unpack_from("<H", payload, 0)[0] & 0x0FFF
                dlen = struct.unpack_from("<H", payload, 2)[0]
                c = self._ctr(h)
                if opcode == MON_ACL_TX:
                    c["tx_b"] += dlen
                    c["tx_p"] += 1
                    q = self.fifo.setdefault(h, deque(maxlen=FIFO_MAX))
                    q.append(dlen)
                else:
                    c["rx_b"] += dlen
                    c["rx_p"] += 1
            elif opcode in (MON_SCO_TX, MON_SCO_RX) and len(payload) >= 3:
                h = struct.unpack_from("<H", payload, 0)[0] & 0x0FFF
                c = self._ctr(h)
                c["sco_tx_b" if opcode == MON_SCO_TX else "sco_rx_b"] += payload[2]
            elif opcode == MON_EVENT_PKT and len(payload) >= 2:
                evt, plen = payload[0], payload[1]
                body = payload[2:2 + plen]
                if evt == EVT_NUM_COMPLETED and body:
                    n = body[0]
                    for i in range(n):
                        if len(body) < 1 + 2 * n + 2 * (i + 1):
                            break
                        h = struct.unpack_from("<H", body, 1 + 2 * i)[0] & 0x0FFF
                        cnt = struct.unpack_from("<H", body, 1 + 2 * n + 2 * i)[0]
                        c = self._ctr(h)
                        q = self.fifo.setdefault(h, deque(maxlen=FIFO_MAX))
                        for _ in range(cnt):
                            c["done_p"] += 1
                            if q:
                                c["done_b"] += q.popleft()
                            else:
                                c["done_unmatched"] += 1      # sent before the meter started
                elif evt == EVT_DISCONN_COMPLETE and len(body) >= 3:
                    h = struct.unpack_from("<H", body, 1)[0] & 0x0FFF
                    self.fifo.pop(h, None)
                    self.addr_of.pop(h, None)
                elif evt == EVT_CONN_COMPLETE and len(body) >= 9 and body[0] == 0:
                    h = struct.unpack_from("<H", body, 1)[0] & 0x0FFF
                    self.addr_of[h] = ":".join("%02X" % b for b in reversed(body[3:9]))
                elif evt == EVT_LE_META and len(body) >= 12 and body[0] in (0x01, 0x0A, 0x29) and body[1] == 0:
                    h = struct.unpack_from("<H", body, 2)[0] & 0x0FFF
                    self.addr_of[h] = ":".join("%02X" % b for b in reversed(body[6:12]))

    def run(self):
        while not self.stop_ev.is_set():
            try:
                data, _anc, flags, _addr = self.sock.recvmsg(65536)
            except socket.timeout:
                continue
            except OSError as e:
                self.error = str(e)
                return
            self.frames += 1
            if flags & socket.MSG_TRUNC:
                self.truncated += 1
            if len(data) < 6:
                continue
            opcode, index, ln = struct.unpack_from("<HHH", data, 0)
            if index != self.hci:
                continue
            self.feed(opcode, data[6:6 + ln])

    # ------------------------------------------------------------- integrity
    def integrity(self):
        """Can the numbers be trusted? The kernel does not report dropped monitor frames, so loss is detected from
        invariants of the data itself: a dropped transmit frame shows up as a completion with nothing to match, and a
        dropped completion event as a send backlog no controller could hold."""
        with self.lock:
            unmatched = sum(c["done_unmatched"] for c in self.c.values())
            backlog = max((len(q) for q in self.fifo.values()), default=0)
        notes = []
        if self.error:
            notes.append("monitor socket error: %s" % self.error)
        if self.truncated:
            notes.append("%d frame(s) truncated by the kernel" % self.truncated)
        if unmatched > STARTUP_GRACE_PKTS:
            notes.append("%d completion(s) matched no sent packet (frames were probably dropped)" % unmatched)
        if backlog > MAX_BACKLOG_PKTS:
            notes.append("send backlog of %d packets (completion events were probably missed)" % backlog)
        return {"ok": not notes, "frames": self.frames, "truncated": self.truncated,
                "unmatched_completions": unmatched, "max_backlog_pkts": backlog, "notes": notes}

    # ------------------------------------------------------------- readout
    def handles_for(self, addr):
        with self.lock:
            return [h for h, a in self.addr_of.items() if a == addr]

    def snapshot(self, handles=None):
        """Cumulative counters (summed over `handles`, or all) with a monotonic timestamp."""
        with self.lock:
            keys = self.c.keys() if handles is None else [h for h in handles if h in self.c]
            tot = {k: 0 for k in ("tx_b", "tx_p", "done_b", "done_p", "done_unmatched", "rx_b", "rx_p")}
            for h in keys:
                for k in tot:
                    tot[k] += self.c[h][k]
            tot["t"] = time.monotonic()
            return tot


    def snapshot_all(self):
        """Per-handle copy of the cumulative counters + one monotonic timestamp."""
        with self.lock:
            return {"t": time.monotonic(), "per": {h: dict(c) for h, c in self.c.items()}}


_KEYS = ("tx_b", "tx_p", "done_b", "done_p", "rx_b", "rx_p")


def totals(snap, handles=None):
    per = snap["per"]
    hs = per.keys() if handles is None else [h for h in handles if h in per]
    out = {k: 0 for k in _KEYS}
    for h in hs:
        for k in _KEYS:
            out[k] += per[h][k]
    return out


def rates_for(prev, cur, handles=None):
    """Exact kbit/s between two snapshot_all() results, for `handles` (None = every connection
    on the controller). Counters are cumulative per handle, so a reconnect (new handle) is safe."""
    dt = cur["t"] - prev["t"]
    if dt <= 0:
        return None
    zero = {k: 0 for k in _KEYS}
    hs = list(cur["per"].keys()) if handles is None else [h for h in handles if h in cur["per"]]
    d = {k: 0 for k in _KEYS}
    for h in hs:
        p = prev["per"].get(h, zero)
        for k in _KEYS:
            d[k] += cur["per"][h][k] - p[k]
    return {"dt": round(dt, 3), "tx_kbps": round(d["tx_b"] * 8.0 / dt / 1000.0, 2),
            "done_kbps": round(d["done_b"] * 8.0 / dt / 1000.0, 2),
            "rx_kbps": round(d["rx_b"] * 8.0 / dt / 1000.0, 2), "tx_pps": round(d["tx_p"] / dt, 1),
            "tx_bytes": d["tx_b"], "done_bytes": d["done_b"], "rx_bytes": d["rx_b"]}


def rates(prev, cur):
    """kbit/s between two snapshots over their exact elapsed time (None if no time passed)."""
    dt = cur["t"] - prev["t"]
    if dt <= 0:
        return None
    def r(k):
        return round((cur[k] - prev[k]) * 8.0 / dt / 1000.0, 2)
    return {"dt": round(dt, 3), "tx_kbps": r("tx_b"), "done_kbps": r("done_b"), "rx_kbps": r("rx_b"),
            "tx_pps": round((cur["tx_p"] - prev["tx_p"]) / dt, 1)}
