# BluForge access control

The BluForge server runs as root and can start jobs, claim radios and install packages, so it is protected as follows
(changed 2026-10-27; before this the server had no login).

## What protects it
1. **Listens on every interface by default** (`--host 0.0.0.0`), so the page is reachable at the unit's IP
   (`http://<unit-ip>:5480/?token=...`). The token below is required either way. For this-machine-only access use
   `--host 127.0.0.1` (installer: `sudo GUI_HOST=127.0.0.1 ./install.sh`). The token and cookie travel over plain
   HTTP, so use a trusted network, or put TLS or an SSH tunnel in front of it.
2. **Access token.** A random token is created on first start and stored in `/var/lib/bluforge/token` (mode 0600, root only;
   change the location with `--token-file`). Every page, script, API call and the live stream require it.
3. **Cookie after first use.** Open `http://host:5480/?token=<token>` once (the server prints this URL at start-up) or type the token
   into the login form. The server then sets an `HttpOnly; SameSite=Strict` cookie; the token is no longer in the address bar.
4. **Cross-site protection** for every request that changes something: the `Origin` header must match the server, a
   cross-site `Sec-Fetch-Site` is refused, and the body must be `application/json` (a web page on another site cannot send that
   without a permission check it will fail).
5. **DNS-rebinding guard:** when listening on loopback, the `Host` header must be `localhost`, `127.0.0.1` or `[::1]`.
6. **Brute-force limit:** 8 wrong tokens in a minute from one address locks login for that address for the rest of the minute.

## Everyday use
- Read the token: `sudo cat /var/lib/bluforge/token`
- Rotate it: `sudo rm /var/lib/bluforge/token && sudo systemctl restart ericsson-bluforge` (all browsers must sign in again).
- A signed-out page (expired cookie, rotated token) reloads to the login form by itself.

## Not covered
- No TLS (plain HTTP). The token and cookie are readable by anyone who can see the traffic on a non-loopback network.
- One shared token, not per-user accounts. Anyone who has it has full control of the unit.
- The cookie has no `Secure` flag because the server speaks plain HTTP.
